export interface IAuthInfo {
  email: string;
  google_id: string;
}
